# 2023-programacao-2-ia21

# Passo 1
Settings / Developer settings / Tokens (classic) / Generate New Token

Note -> qualque nome aqui Expiration -> No Expiration Select scopes -> Selecione todos os escopos

Clique e Generate Token

Anote o Token Gerado em um local seguro

# Passo 2
git clone http://TOKEN@github.com/USUARIO/REPOSITORIO 
git add --all 
git commit -m "MENSAGEM" 
git push

# Passo 3
git pull